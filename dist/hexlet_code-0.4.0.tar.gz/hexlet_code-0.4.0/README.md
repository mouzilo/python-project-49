### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/a7f093db8571a8cbb37b/maintainability)](https://codeclimate.com/github/mouzilo/python-project-49/maintainability)
[![Actions Status](https://github.com/mouzilo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mouzilo/python-project-49/actions)

brain-games: https://asciinema.org/a/kJrXZddguwUx1hljW9ptSH2gJ

brain-even: https://asciinema.org/a/sOZSv509liuti10deihx2ehMi

brain-calc: https://asciinema.org/a/5mXUSgP4XKzo4pJLWmElou2cl

brain-gcd: https://asciinema.org/a/vV5SPKglOPptStefIqNpDLKLZ