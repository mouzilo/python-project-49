#!/usr/bin/env python3


import prompt
from random import randint, choice
from brain_games.games.brain_games import welcome_user, brain_games
from brain_games.games.brain_even import even
from brain_games.games.brain_calc import calc


def welcome_s():
	brain_games()


def calc_s():
	calc()


def even_s():
	even()