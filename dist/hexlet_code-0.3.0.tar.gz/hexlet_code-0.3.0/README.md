### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/a7f093db8571a8cbb37b/maintainability)](https://codeclimate.com/github/mouzilo/python-project-49/maintainability)
[![Actions Status](https://github.com/mouzilo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mouzilo/python-project-49/actions)

https://asciinema.org/connect/ae81e15b-7c91-41bb-bfe9-ac2b49ea2106
